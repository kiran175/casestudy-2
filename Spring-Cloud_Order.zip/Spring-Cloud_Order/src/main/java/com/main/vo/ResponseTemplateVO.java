package com.main.vo;

import com.main.model.Order;

public class ResponseTemplateVO {
	
	private Order order;
	private Product product;
	public ResponseTemplateVO() {
		super();
	}
	public ResponseTemplateVO(Order order, Product product) {
		super();
		this.order = order;
		this.product = product;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	

}
