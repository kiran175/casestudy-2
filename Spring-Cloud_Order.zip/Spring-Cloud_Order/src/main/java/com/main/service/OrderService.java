package com.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.main.model.Order;
import com.main.repository.OrderRepository;
import com.main.vo.Product;
import com.main.vo.ResponseTemplateVO;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository repository;
	@Autowired
	private RestTemplate restTemplate;

	public void saveOder(Order order) {
		repository.save(order);
		
	}

	public ResponseTemplateVO getOrderWithProduct(Long orderId) {
		ResponseTemplateVO vo=new ResponseTemplateVO();
		Order order=repository.findByOrderId(orderId);
		Product product=restTemplate.getForObject("http://PRODUCT-SERVICE/products/fetchById/"+order.getProductId(),Product.class);
		
		vo.setOrder(order);
		vo.setProduct(product);
		
		return vo;
	}

	public List<Order> fetchProducts() {
		
		return repository.findAll();
	}

}
