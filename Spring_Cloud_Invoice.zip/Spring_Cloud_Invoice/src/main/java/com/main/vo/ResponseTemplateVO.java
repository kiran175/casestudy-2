package com.main.vo;

import com.main.model.Invoice;

public class ResponseTemplateVO {
	
	private Order order;
	private Product product;
	private Invoice invoice;
	public ResponseTemplateVO() {
		super();
	}
	public ResponseTemplateVO(Order order, Product product, Invoice invoice) {
		super();
		this.order = order;
		this.product = product;
		this.invoice = invoice;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Invoice getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	@Override
	public String toString() {
		return "ResponseTemplateVO [order=" + order + ", product=" + product + ", invoice=" + invoice + "]";
	}
	

}
