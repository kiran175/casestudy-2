package com.main.vo;

public class Order {
	
	private Long orderId;
    private String cust_name;
    private String address;
    private String status;
    private int productId;
    private int quantity;
	public Order() {
		super();
	}
	public Order(Long orderId, String cust_name, String address, String status, int productId, int quantity) {
		super();
		this.orderId = orderId;
		this.cust_name = cust_name;
		this.address = address;
		this.status = status;
		this.productId = productId;
		this.quantity = quantity;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
    
    

}
