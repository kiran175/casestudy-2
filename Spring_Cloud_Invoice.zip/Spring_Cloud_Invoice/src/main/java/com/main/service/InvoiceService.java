package com.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.main.repository.InvoiceRepository;
import com.main.vo.Order;
import com.main.vo.Product;

@Service
public class InvoiceService {
	
	@Autowired
	private InvoiceRepository repository;
	@Autowired
	private RestTemplate restTemplate;

	public void saveInvoice(Invoice invoice) {
		Order order=restTemplate.getForObject("http://localhost:2022/orders/getOrder/"+invoice.getOrder_id(),Order.class);
		Product product=restTemplate.getForObject("http://localhost:2021/products/fetchById/"+order.getProductId(),Product.class);
		invoice.setTotal(order.getQuantity()*product.getPrice());
		
		repository.save(invoice);
		
	}

	public Invoice getInvoiceById(int id) {
		
		return  repository.findById(id);
	}

	

}
