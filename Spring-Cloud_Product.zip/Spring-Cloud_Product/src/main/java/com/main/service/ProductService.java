package com.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.model.Product;
import com.main.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository repository;
	
	public Product saveProduct(Product product) {
		return repository.save(product); 
	}

	public Product findProductById(Long productId) {
		
		return repository.findByProductId(productId) ;
	}

	public List<Product> fetchProducts() {
		return repository.findAll();
		
	}

}
