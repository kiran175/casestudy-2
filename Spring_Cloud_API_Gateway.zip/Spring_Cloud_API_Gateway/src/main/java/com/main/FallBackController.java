package com.main;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackController {
	@GetMapping("/orderServiceFallBack")
	public String orderServiceFallBackMethod() {
		
		return "Order service is taking longer than Expected. Please try again later";
		
	}
	
	@GetMapping("/productServiceFallBack")
	public String productServiceFallBackMethod() {
		
		return "Product service is taking longer than Expected. Please try again later";
		
	}

}
